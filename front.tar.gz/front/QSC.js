function rand(){
  var num = prompt("请输入参加抽奖的人数",1);
 /* for(var i=0,i<7,i++){
    setTimeout(function(){
      var flash= (Array(4).join('0') + Math.floor(Math.random() * 9999 + 1)).slice(-4)
      document.getElementById("random").innerHTML = out_put;},20);
  }*/
  var out_put = (Array(4).join('0') + Math.floor(Math.random() * (num) + 1)).slice(-4);//补齐0产生四位数
  document.getElementById("random").innerHTML = out_put;
}
